# 我的Hackintosh启动efi

使用opencore引导（当前版本0.6.8-release）

适合macos版本：10.15

电脑硬件：

- cpu：i5-9400f
- gpu：gtx650
- 主板：msi-b360M-Wind

网络使用USB网卡解决。